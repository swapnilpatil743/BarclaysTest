package com.example.barc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BarcApplication {

	public static void main(String[] args) {
		SpringApplication.run(BarcApplication.class, args);
	}

}
